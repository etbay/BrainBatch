import{a5 as a}from"./C7H14__D.js";a();
