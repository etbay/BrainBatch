import{l as o,d as r}from"../chunks/BbPlUrqJ.js";export{o as load_css,r as start};
